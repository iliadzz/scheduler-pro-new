export interface Department {
  id: string;
  name: string;
  abbreviation: string;
  sortOrder: number;
}