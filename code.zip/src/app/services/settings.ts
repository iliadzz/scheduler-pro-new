import { Injectable, signal } from '@angular/core';

export type TimeFormat = '24h' | '12h';
export interface AppSettings { timeFormat: TimeFormat; }

@Injectable({ providedIn: 'root' })
export class SettingsService {
  private _settings = signal<AppSettings>({ timeFormat: '24h' });
  readonly settings = this._settings.asReadonly();

  setTimeFormat(fmt: TimeFormat) {
    this._settings.update(s => ({ ...s, timeFormat: fmt }));
    localStorage.setItem('app.settings', JSON.stringify(this._settings()));
  }

  load() {
    const raw = localStorage.getItem('app.settings');
    if (raw) this._settings.set(JSON.parse(raw));
  }
}
